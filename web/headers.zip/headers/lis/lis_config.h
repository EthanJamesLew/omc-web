/* include/lis_config.h.  Generated from lis_config.h.in.cmake by CMake.  */

/* Define to dummy `main' function (if any) required to link to the Fortran
   libraries. */
/* #undef F77_DUMMY_MAIN */

/* Define to a macro mangling the given C identifier (in lower and upper
   case), which must not contain underscores, for linking with Fortran. */
/* #undef F77_FUNC */

/* As F77_FUNC, but for C identifiers containing underscores. */
/* #undef F77_FUNC_ */

/* Define if F77 and FC dummy `main' functions are identical. */
/* #undef FC_DUMMY_MAIN_EQ_F77 */

/* Define to 1 to enable quad precision operations using FMA. */
/* #undef HAS_FMA */

/* Define to 1 to enable x87 FPU. */
/* #undef HAS_X87_FPU */

/* Define to 1 if you have the <dlfcn.h> header file. */
#define HAVE_DLFCN_H 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define to 1 if you have the <malloc.h> header file. */
#define HAVE_MALLOC_H 1

/* Define to 1 if you have the <memory.h> header file. */
#define HAVE_MEMORY_H 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/time.h> header file. */
#define HAVE_SYS_TIME_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define to the sub-directory in which libtool stores uninstalled libraries.
   */
/* #undef LT_OBJDIR */

/* Define to the address where bug reports for this package should be sent. */
/* #undef PACKAGE_BUGREPORT */

/* Define to the full name of this package. */
/* #undef PACKAGE_NAME */

/* Define to the full name and version of this package. */
/* #undef PACKAGE_STRING */

/* Define to the one symbol short name of this package. */
/* #undef PACKAGE_TARNAME */

/* Define to the home page for this package. */
/* #undef PACKAGE_URL */

/* Define to the version of this package. */
/* #undef PACKAGE_VERSION */

/* Test the size of a `double', as computed by sizeof. */
#define SIZEOF_DOUBLE 8

/* Test the size of a `float', as computed by sizeof. */
#define SIZEOF_FLOAT 4

/* Test the size of a `int', as computed by sizeof. */
#define SIZEOF_INT 4

/* Test the size of a `long', as computed by sizeof. */
#define SIZEOF_LONG 4

/* Test the size of a `long double', as computed by sizeof. */
#define SIZEOF_LONG_DOUBLE 16

/* Test the size of a `long long', as computed by sizeof. */
#define SIZEOF_LONG_LONG 8

/* Test the size of a `size_t', as computed by sizeof. */
#define SIZEOF_SIZE_T 4

/* Test the size of a `void *', as computed by sizeof. */
#define SIZEOF_VOID_P 4

/* Define to 1 if you have the ANSI C header files. */
/* #undef STDC_HEADERS */

/* Define to 1 to build quad precision operations using fast quad add. */
/* #undef USE_FAST_QUAD_ADD */

/* Define to 1 to enable quad precision operations using FMA and SSE2. */
/* #undef USE_FMA2_SSE2 */

/* Define to 1 to enable Fortran 77 subroutines. */
/* #undef USE_FORTRAN */

/* Use MAIN__ macro with Fortran. */
/* #undef USE_MAIN__ */

/* Define to 1 to enable overlapping of lis_sendrecv. */
/* #undef USE_OVERLAP */

/* Define to 1 to enable quad precision operations. */
/* #undef USE_QUAD_PRECISION */

/* Define to 1 to enable SA-AMG preconditioner. */
/* #undef USE_SAAMG */

/* Define to 1 to enable quad precision operations using SSE2. */
/* #undef USE_SSE2 */

/* Define to 1 to use vectorization. */
/* #undef USE_VEC_COMP */

/* Define to empty if `const' does not conform to ANSI C. */
/* #undef const */

/* Define to `unsigned int' if <sys/types.h> does not define. */
/* #undef size_t */
