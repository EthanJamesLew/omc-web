/*
 * This file belongs to the OpenModelica Run-Time System
 *
 * Copyright (c) 1998-2026, Open Source Modelica Consortium (OSMC), c/o Linköpings
 * universitet, Department of Computer and Information Science, SE-58183 Linköping, Sweden. All rights
 * reserved.
 *
 * THIS PROGRAM IS PROVIDED UNDER THE TERMS OF THE BSD NEW LICENSE OR THE
 * AGPL VERSION 3 LICENSE OR THE OSMC PUBLIC LICENSE (OSMC-PL) VERSION 1.8. ANY
 * USE, REPRODUCTION OR DISTRIBUTION OF THIS PROGRAM CONSTITUTES RECIPIENT'S
 * ACCEPTANCE OF THE BSD NEW LICENSE OR THE OSMC PUBLIC LICENSE OR THE AGPL
 * VERSION 3, ACCORDING TO RECIPIENTS CHOICE.
 *
 * The OpenModelica software and the OSMC (Open Source Modelica Consortium) Public License
 * (OSMC-PL) are obtained from OSMC, either from the above address, from the URLs:
 * http://www.openmodelica.org or https://github.com/OpenModelica/ or
 * http://www.ida.liu.se/projects/OpenModelica, and in the OpenModelica distribution. GNU
 * AGPL version 3 is obtained from: https://www.gnu.org/licenses/licenses.html#GPL. The BSD NEW
 * License is obtained from: http://www.opensource.org/licenses/BSD-3-Clause.
 *
 * This program is distributed WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE, EXCEPT AS EXPRESSLY
 * SET FORTH IN THE BY RECIPIENT SELECTED SUBSIDIARY LICENSE CONDITIONS OF
 * OSMC-PL.
 *
 */

/*! \file sundials_util.h
 */

#ifndef _SUNDIALS_URIL_H
#define _SUNDIALS_URIL_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef OMC_FMI_RUNTIME
  #include "omc_config.h"
#endif

#ifdef WITH_SUNDIALS
#include <sundials/sundials_matrix.h>
#include "../jacobian_util.h"

void setJacElementSundialsSparse(int row, int column, int nth, double value, void* Jac, int nRows);
void setSundialsSparsePattern(JACOBIAN* jacobian, SUNMatrix Jac);
int _omc_SUNMatScaleIAdd_Sparse(realtype c, SUNMatrix A);
int _omc_SUNSparseMatrixVecScaling(SUNMatrix A, N_Vector vScale);

#endif /* WITH_SUNDIALS */

#ifdef __cplusplus
};
#endif

#endif /* _SUNDIALS_URIL_H */
